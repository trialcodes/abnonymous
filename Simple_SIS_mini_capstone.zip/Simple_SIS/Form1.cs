﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MetroFramework.Forms;
using MySql.Data.MySqlClient;

namespace Simple_SIS
{
    public partial class Form1 : MetroForm
    {

        public static string text;

        public Form1()
             
        {
            InitializeComponent();
          
              text = label8.Text;

        }

        MySqlConnection con = new MySqlConnection("server=localhost;username=root;database=mysql;"); 
        MySqlDataReader dr;
        MySqlCommand com;


        public void saveparams2()
        {
            com.Parameters.AddWithValue("@id", "0");
            com.Parameters.AddWithValue("@id2", "1");
            com.Parameters.AddWithValue("@logopath", label9.Text);
        }


        public void reloadlogopath2()
        {
            com = new MySqlCommand("select * from db_sisvone.tb_settings where id=@id2", con);
            saveparams2();
            dr = com.ExecuteReader();
            while (dr.Read())
            {
               label9.Text = dr.GetString(1).ToString();
            }
            dr.Close();
            pictureBox1.ImageLocation = label9.Text;
        }



        private void Form1_Load(object sender, EventArgs e)
        {
          
          
            con.Open();
             com = new MySqlCommand("create database if not exists db_sisvone",con);
            dr = com.ExecuteReader();
            dr.Close();

            com = new MySqlCommand("create table if not exists db_sisvone.tb_studentdetails(id int(100) auto_increment primary key, idnumber varchar(100), lastname text, firstname text, middlename text, couse text, year_level text, address text, sex text, birthdate text, age int(2), s_contactno varchar(11), scholar varchar(3), graduated varchar(3), father text, mother text, cpe_fullname text, cpe_contactno text, date text, processedby text);",con);
            dr = com.ExecuteReader();
            dr.Close();

            com = new MySqlCommand("create table if not exists db_sisvone.tb_settings(id int(100) auto_increment primary key, logopath text)",con);
            dr = com.ExecuteReader();
            dr.Close();

            reloadlogopath2();

            IsMdiContainer = true;

            button1.FlatAppearance.MouseDownBackColor = Color.Green;
                button1 .FlatAppearance .BorderSize = 1;
                button1.FlatAppearance.MouseOverBackColor = Color.Lime;

                button2.FlatAppearance.MouseDownBackColor = Color.Green;
                button2.FlatAppearance.BorderSize = 1;
                button2.FlatAppearance.MouseOverBackColor = Color.Lime;

                button3.FlatAppearance.MouseDownBackColor = Color.Green;
                button3.FlatAppearance.BorderSize = 1;
                button3.FlatAppearance.MouseOverBackColor = Color.Lime;

                button4.FlatAppearance.MouseDownBackColor = Color.Green;
                button4.FlatAppearance.BorderSize = 1;
                button4.FlatAppearance.MouseOverBackColor = Color.Lime;

                button5.FlatAppearance.MouseDownBackColor = Color.Green;
                button5.FlatAppearance.BorderSize = 1;
                button5.FlatAppearance.MouseOverBackColor = Color.Lime;

                button7.FlatAppearance.MouseDownBackColor = Color.Green;
                button7.FlatAppearance.BorderSize = 1;
                button7.FlatAppearance.MouseOverBackColor = Color.Lime;

                button6.FlatAppearance.MouseDownBackColor = Color.Green;
                button6.FlatAppearance.BorderSize = 1;
                button6.FlatAppearance.MouseOverBackColor = Color.Lime;

                button8.FlatAppearance.MouseDownBackColor = Color.Green;
                button8.FlatAppearance.BorderSize = 1;
                button8.FlatAppearance.MouseOverBackColor = Color.Lime;

                button9.FlatAppearance.MouseDownBackColor = Color.Green;
                button9.FlatAppearance.BorderSize = 1;
                button9.FlatAppearance.MouseOverBackColor = Color.Lime;

                button10.FlatAppearance.MouseDownBackColor = Color.Green;
                button10.FlatAppearance.BorderSize = 1;
                button10.FlatAppearance.MouseOverBackColor = Color.Lime;

                button11.FlatAppearance.MouseDownBackColor = Color.Green;
                button11.FlatAppearance.BorderSize = 1;
                button11.FlatAppearance.MouseOverBackColor = Color.Lime;

                button12.FlatAppearance.MouseDownBackColor = Color.Green;
                button12.FlatAppearance.BorderSize = 1;
                button12.FlatAppearance.MouseOverBackColor = Color.Lime;

                button13.FlatAppearance.MouseDownBackColor = Color.Green;
                button13.FlatAppearance.BorderSize = 1;
                button13.FlatAppearance.MouseOverBackColor = Color.Lime;

                button14.FlatAppearance.MouseDownBackColor = Color.Green;
                button14.FlatAppearance.BorderSize = 1;
                button14.FlatAppearance.MouseOverBackColor = Color.Lime;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            foreach (MetroForm subforms in this.MdiChildren) {
                subforms.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
      
            groupBox1.Visible = false;
            if (ActiveMdiChild != null)
                ActiveMdiChild.Close();
            f_students subform1 = new f_students();
            subform1.MdiParent = this;
            subform1.Show();
         
        }

        private void button3_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            if (ActiveMdiChild != null)
                ActiveMdiChild.Close();
               fcourses subform1 = new fcourses ();
            subform1.MdiParent = this;
            subform1.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            if (ActiveMdiChild != null)
                ActiveMdiChild.Close();
            fsubjects subform1 = new fsubjects();
            subform1.MdiParent = this;
            subform1.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            if (ActiveMdiChild != null)
                ActiveMdiChild.Close();
            fscholars subform1 = new fscholars();
            subform1.MdiParent = this;
            subform1.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
           
            groupBox1.Visible = false;
            if (ActiveMdiChild != null)
                ActiveMdiChild.Close();
            fgraduated subform1 = new fgraduated();
            subform1.MdiParent = this;
            subform1.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
            groupBox1.Visible = false;
            if (ActiveMdiChild != null)
                ActiveMdiChild.Close();
            fusers subform1 = new fusers();
            subform1.MdiParent = this;
            subform1.Show();
        }

        public void closesubforms()
        {
           

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (ActiveMdiChild != null)
                ActiveMdiChild.Close();
            groupBox1.Visible = true;
           
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            if (ActiveMdiChild != null)
                ActiveMdiChild.Close();
            settings subform1 = new settings();
            subform1.MdiParent = this;
            subform1.Show();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_MouseEnter(object sender, EventArgs e)
        {
            reloadlogopath2();
        }


    }
}
