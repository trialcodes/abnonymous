﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Simple_SIS
{
    class Class1
    {
      //  MySqlConnection con = new MySqlConnection("server=localhost;username=root;database=mysql;");
     //   MySqlCommand com;
     //   MySqlDataReader dr;


      

    }
}
