﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Simple_SIS
{
    public partial class settings : Form
    {
        public settings()
        {
            InitializeComponent();
        }

        MySqlConnection con = new MySqlConnection("server=localhost;username=root;database=mysql;");
        MySqlCommand com;
        MySqlDataReader dr;


        private void settings_Load(object sender, EventArgs e)
        {
            con.Open();
            reloadlogopath();
            textBox1.ReadOnly = true;

        }

        public void saveparams2() {
            com.Parameters.AddWithValue("@id", "0");
            com.Parameters.AddWithValue("@id2", "1");
            com.Parameters.AddWithValue("@logopath",textBox1.Text);
        }


        public void reloadlogopath() {
            com = new MySqlCommand("select * from db_sisvone.tb_settings where id=@id2", con);
            saveparams2();
            dr = com.ExecuteReader();
            while (dr.Read()) {
                label4.Text = dr.GetInt32(0).ToString();
                textBox1.Text = dr.GetString(1).ToString();
            }
            dr.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {


            }
            else
            {
                if (label4.Text == "0")
                {
                    com = new MySqlCommand("insert into db_sisvone.tb_settings(id, logopath)values(@id, @logopath);", con);
                    saveparams2();
                    dr = com.ExecuteReader();
                    dr.Close();
                }
                else
                {
                    com = new MySqlCommand("update db_sisvone.tb_settings set id =  @id2, logopath=@logopath where id =  @id2;", con);
                    saveparams2();
                    dr = com.ExecuteReader();
                    dr.Close();
                }
                MessageBox.Show("Logo is now saved.","Saved Successfully",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            reloadlogopath();
        }

        private void buttonsave_Click(object sender, EventArgs e)
        {
            OpenFileDialog logopath = new OpenFileDialog();
            {
                if (DialogResult.OK == logopath.ShowDialog()) {
                    textBox1.Text = logopath.FileName;
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == ""){ 
            
            }else{
                pictureBox1.ImageLocation = textBox1.Text;
            }

        }
    }
}
