﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Simple_SIS
{
    public partial class fstudent_details : Form
    {

        MySqlConnection con = new MySqlConnection("server=localhost;username=root;database=mysql;");
        MySqlDataReader dr;
        MySqlCommand com;
      

        public fstudent_details()
        {
            InitializeComponent();
    

        }

        private void button2_Click(object sender, EventArgs e)
        {
       
            
        }

        private void fstudent_details_Load(object sender, EventArgs e)
        {
            
          //  MinimizeBox = false;
          //  MaximizeBox = false;
             

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {
        
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Dispose();
        }

      

        private void textBox12_KeyUp(object sender, KeyEventArgs e)
        {

        }

        public void saveparams() {
            com.Parameters.AddWithValue("@idnumber", txtid.Text);
            com.Parameters.AddWithValue("@lastname", textBox2.Text);
            com.Parameters.AddWithValue("@firstname", textBox3.Text);
            com.Parameters.AddWithValue("@middlename", textBox4.Text);
            com.Parameters.AddWithValue("@couse", textBox5.Text);
            com.Parameters.AddWithValue("@year_level", cboxyear.Text);
            com.Parameters.AddWithValue("@address", textBox7.Text);
            com.Parameters.AddWithValue("@sex", comboBox2.Text);
            com.Parameters.AddWithValue("@birthdate", dateTimePicker1.Text);
            com.Parameters.AddWithValue("@age", textBox6.Text);
            com.Parameters.AddWithValue("@s_contactno", textBox8.Text);
            com.Parameters.AddWithValue("@scholar", comboBox3.Text);
            com.Parameters.AddWithValue("@graduated", comboBox4.Text);
            com.Parameters.AddWithValue("@father", textBox9.Text);
            com.Parameters.AddWithValue("@mother", textBox10.Text);
            com.Parameters.AddWithValue("@cpe_fullname", textBox11.Text);
            com.Parameters.AddWithValue("@cpe_contactno", textBox12.Text);
            com.Parameters.AddWithValue("@date", "Today");
            com.Parameters.AddWithValue("@processedby", "System Administrator");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if(textBox2.Text =="" || textBox3.Text=="" || textBox4.Text==""){
                MessageBox.Show("Please complete requied information.", MessageBoxIcon.Exclamation + " : Missing Details");
            }else{
            con.Open();
            com = new MySqlCommand("insert into db_sisvone.tb_studentdetails(idnumber, lastname, firstname, middlename, couse, year_level, address, sex, birthdate, age, s_contactno, scholar, graduated, father, mother, cpe_fullname, cpe_contactno, date, processedby)values(@idnumber, @lastname, @firstname, @middlename, @couse, @year_level, @address, @sex, @birthdate, @age, @s_contactno, @scholar, @graduated, @father, @mother, @cpe_fullname, @cpe_contactno, @date, @processedby)", con);
            saveparams();
            dr = com.ExecuteReader();
            dr.Close();
            con.Close();
            MessageBox.Show("New student details saved.",MessageBoxIcon.Stop  +" : Saved Successfully");
            this.Close();
            }
            
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
           if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char) Keys.Back) {

               e.Handled = false;

           }else{
               e.Handled = true ;
           }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back)
            {

                e.Handled = false;

            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back)
            {

                e.Handled = false;

            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            textBox6.MaxLength = 2;
            if ((char.IsDigit(e.KeyChar)) || e.KeyChar == (char)Keys.Back)
            {

                e.Handled = false;

            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            textBox8.MaxLength = 11;
            if ((char.IsDigit(e.KeyChar)) || e.KeyChar == (char)Keys.Back)
            {

                e.Handled = false;

            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back)
            {

                e.Handled = false;

            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || (char.IsDigit(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {

                e.Handled = false;

            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox9_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox11_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
          
           int age = DateTime.Today.Year  - dateTimePicker1.Value.Year;
           textBox6.Text = age.ToString();


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            if (cboxyear.Text == "4th" || cboxyear.Text == "5th")
            {
                comboBox4.Text = "YES";
            }
            else
            {
                comboBox4.Text = "NO";
            }
        }

      
    }
}
