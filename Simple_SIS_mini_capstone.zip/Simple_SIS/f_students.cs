﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Simple_SIS
{

    public partial class f_students : Form
    {
        MySqlConnection con = new MySqlConnection("server=localhost;username=root;database=mysql;");
        MySqlCommand com;
        MySqlDataReader dr;


        public f_students()
        {
            InitializeComponent();

        }


        public void search_details()
        {
            listView1.Items.Clear();
            com = new MySqlCommand("select * from db_sisvone.tb_studentdetails where idnumber like '%" + textBox1.Text + "%' or firstname like '%" + textBox1.Text + "%' or lastname like '%" + textBox1.Text + "%' or couse like '%" + textBox1.Text + "%';", con);
            dr = com.ExecuteReader();
            while (dr.Read())
            {
                lv_items();
            }
            dr.Close();
        }

        public void search_year_level()
        {
            listView1.Items.Clear();
            com = new MySqlCommand("select * from db_sisvone.tb_studentdetails where year_level='" + comboBox1.Text + "';", con);
            dr = com.ExecuteReader();
            while (dr.Read())
            {
                lv_items();
            }
            dr.Close();
        }


        public void reload_details()
        {
            listView1.Items.Clear();
            com = new MySqlCommand("select * from db_sisvone.tb_studentdetails order by id desc;", con);
            dr = com.ExecuteReader();
            while (dr.Read())
            {
                lv_items();
            }
            dr.Close();
            Process.Start("simple_sis_mod.exe");
        }


        public void counts_students()
        {
            com = new MySqlCommand("select count(id) from db_sisvone.tb_studentdetails;", con);
            dr = com.ExecuteReader();
            while (dr.Read())
            {

                label1.Text = dr.GetInt32(0).ToString(); // yan 
            }
            dr.Close();
        }

        public void counts_scholarYES()
        {
            com = new MySqlCommand("select count(scholar) from db_sisvone.tb_studentdetails where scholar='" + "YES" + "';", con);
            dr = com.ExecuteReader();
            while (dr.Read())
            {

                label2.Text = dr.GetInt32(0).ToString();
            }
            dr.Close();
        }


        public void counts_scholarNO()
        {
            com = new MySqlCommand("select count(scholar) from db_sisvone.tb_studentdetails where scholar='" + "NO" + "';", con);
            dr = com.ExecuteReader();
            while (dr.Read())
            {

                label10.Text = dr.GetInt32(0).ToString();
            }
            dr.Close();
        }

        public void counts_graduatedYES()
        {
            com = new MySqlCommand("select count(graduated) from db_sisvone.tb_studentdetails where graduated='" + "YES" + "';", con);
            dr = com.ExecuteReader();
            while (dr.Read())
            {

                label11.Text = dr.GetInt32(0).ToString();
            }
            dr.Close();
        }


        public void counts_graduatedNO()
        {
            com = new MySqlCommand("select count(graduated) from db_sisvone.tb_studentdetails where graduated='" + "NO" + "';", con);
            dr = com.ExecuteReader();
            while (dr.Read())
            {

                label12.Text = dr.GetInt32(0).ToString();
            }
            dr.Close();
        }

        public void lv_items()
        {
            ListViewItem details = new ListViewItem(dr.GetInt32(0).ToString());
            details.SubItems.Add(dr.GetString(1).ToString());
            details.SubItems.Add(dr.GetString(2).ToString());
            details.SubItems.Add(dr.GetString(3).ToString());
            details.SubItems.Add(dr.GetString(4).ToString());
            details.SubItems.Add(dr.GetString(5).ToString());
            details.SubItems.Add(dr.GetString(6).ToString());
            details.SubItems.Add(dr.GetString(7).ToString());
            details.SubItems.Add(dr.GetString(8).ToString());
            details.SubItems.Add(dr.GetString(9).ToString());
            details.SubItems.Add(dr.GetString(10).ToString());
            details.SubItems.Add(dr.GetString(11).ToString());
            details.SubItems.Add(dr.GetString(12).ToString());
            details.SubItems.Add(dr.GetString(13).ToString());
            details.SubItems.Add(dr.GetString(14).ToString());
            details.SubItems.Add(dr.GetString(15).ToString());
            details.SubItems.Add(dr.GetString(16).ToString());
            details.SubItems.Add(dr.GetString(17).ToString());
            details.SubItems.Add(dr.GetString(18).ToString());
            details.SubItems.Add(dr.GetString(19).ToString());
            listView1.Items.Add(details);
            if (dr.GetString(13).ToString() == "YES")
            {
                details.BackColor = Color.Purple;
            }
            else
            {
                details.BackColor = Color.Green;
            }
            details.ForeColor = Color.White;
        }

        private void textBox12_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            textBox12.MaxLength = 11;
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back)
            {

                e.Handled = false;

            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back)
            {

                e.Handled = false;

            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back)
            {

                e.Handled = false;

            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox6_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            textBox6.MaxLength = 2;
            if ((char.IsDigit(e.KeyChar)) || e.KeyChar == (char)Keys.Back)
            {

                e.Handled = false;

            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox8_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            textBox8.MaxLength = 11;
            if ((char.IsDigit(e.KeyChar)) || e.KeyChar == (char)Keys.Back)
            {

                e.Handled = false;

            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back)
            {

                e.Handled = false;

            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || (char.IsDigit(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {

                e.Handled = false;

            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox9_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox11_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            int age = DateTime.Today.Year - dateTimePicker1.Value.Year;
            textBox6.Text = age.ToString();
        }

        public void selectparams()
        {
            com.Parameters.AddWithValue("@id", listView1.FocusedItem.Text);
        }

        public void selectdetails()
        { //eto guys yung select or kumukuha ng details from out database.
            com = new MySqlCommand("select * from db_sisvone.tb_studentdetails where id=@id", con);
            selectparams();
            dr = com.ExecuteReader();
            while (dr.Read())
            {
                label38.Text = dr.GetInt32(0).ToString();
                txtid.Text = dr.GetString(1).ToString();
                textBox2.Text = dr.GetString(2).ToString();
                textBox3.Text = dr.GetString(3).ToString();
                textBox4.Text = dr.GetString(4).ToString();
                textBox5.Text = dr.GetString(5).ToString();
                cboxyear.Text = dr.GetString(6).ToString();
                textBox7.Text = dr.GetString(7).ToString();
                comboBox2.Text = dr.GetString(8).ToString();
                dateTimePicker2.Text = dr.GetString(9).ToString();
                textBox6.Text = dr.GetInt32(10).ToString();
                textBox8.Text = dr.GetString(11).ToString();
                comboBox3.Text = dr.GetString(12).ToString();
                comboBox4.Text = dr.GetString(13).ToString();
                textBox9.Text = dr.GetString(14).ToString();
                textBox10.Text = dr.GetString(15).ToString();
                textBox11.Text = dr.GetString(16).ToString();
                textBox12.Text = dr.GetString(17).ToString();
            }
            dr.Close();

        }


        private void f_students_Load(object sender, EventArgs e)
        {
            timer1.Start();
            con.Open();
            listView1.View = View.Details;
            listView1.FullRowSelect = true;
            listView1.GridLines = true;
            listView1.Columns.Clear();
            listView1.Columns.Add("id", 0);
            listView1.Columns.Add("ID Number", 150);
            listView1.Columns.Add("Lastname", 100);
            listView1.Columns.Add("Firstname", 100);
            listView1.Columns.Add("Middlename", 100);
            listView1.Columns.Add("Course", 100);
            listView1.Columns.Add("Year Level", 100);
            listView1.Columns.Add("Address", 100);
            listView1.Columns.Add("Sex", 100);
            listView1.Columns.Add("Birthdate", 100);
            listView1.Columns.Add("Age", 100);
            listView1.Columns.Add("Contact No.", 100);
            listView1.Columns.Add("Scholar?", 100);
            listView1.Columns.Add("Graduated?", 100);
            listView1.Columns.Add("Mother's Name", 130);
            listView1.Columns.Add("Father's Name", 130);
            listView1.Columns.Add("CPE - Name", 130);
            listView1.Columns.Add("CPE - Contact No.", 130);
            listView1.Columns.Add("Date", 130);
            listView1.Columns.Add("Processed By", 200);
            Process.Start("simple_sis_mod.exe");
            comboBox1.Items.Clear();
            comboBox1.Items.Add("[ SELECT ]");
            comboBox1.Items.Add("1st");
            comboBox1.Items.Add("2nd");
            comboBox1.Items.Add("3rd");
            comboBox1.Items.Add("4th");
            comboBox1.Items.Add("5ft");
            comboBox1.Text = "[ SELECT ]";

            cboxyear.Items.Clear();
            cboxyear.Items.Add("1st");
            cboxyear.Items.Add("2nd");
            cboxyear.Items.Add("3rd");
            cboxyear.Items.Add("4th");
            cboxyear.Items.Add("5ft");
            cboxyear.Text = "1st";

            comboBox2.Items.Clear();
            comboBox2.Items.Add("Male");
            comboBox2.Items.Add("Female");
            comboBox2.Text = "Male";

            comboBox3.Items.Clear();
            comboBox3.Items.Add("YES");
            comboBox3.Items.Add("NO");
            comboBox3.Text = "YES";

            comboBox4.Items.Clear();
            comboBox4.Items.Add("YES");
            comboBox4.Items.Add("NO");
            comboBox4.Text = "NO";

            textBox6.ReadOnly = true;
            comboBox4.Enabled = false;
            txtid.ReadOnly = true;
            Process.Start("simple_sis_mod.exe");
            txtid.Text = DateTime.Now.ToString("yyyy-MMddhhmmss");
            txtclear();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            Form1.text = "STUDENT";
            this.Close();
        }

        private void label8_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            fstudent_details subform1 = new fstudent_details();
            subform1.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtclear();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            search_details();
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "[ SELECT ]")
            {
                counts_students();
                counts_scholarYES();
                counts_scholarNO();
                counts_graduatedYES();
                counts_graduatedNO();
                reload_details();
            }
            else
            {
                search_year_level();
            }
        }

        public void counts_reload()
        {
            counts_students();
            counts_scholarYES();
            counts_scholarNO();
            counts_graduatedYES();
            counts_graduatedNO();
            reload_details();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            counts_reload();

        }

        public void saveparams()
        {
            com.Parameters.AddWithValue("@idnumber", txtid.Text);
            com.Parameters.AddWithValue("@lastname", textBox2.Text);
            com.Parameters.AddWithValue("@firstname", textBox3.Text);
            com.Parameters.AddWithValue("@middlename", textBox4.Text);
            com.Parameters.AddWithValue("@couse", textBox5.Text);
            com.Parameters.AddWithValue("@year_level", cboxyear.Text);
            com.Parameters.AddWithValue("@address", textBox7.Text);
            com.Parameters.AddWithValue("@sex", comboBox2.Text);
            com.Parameters.AddWithValue("@birthdate", dateTimePicker1.Text);
            com.Parameters.AddWithValue("@age", textBox6.Text);
            com.Parameters.AddWithValue("@s_contactno", textBox8.Text);
            com.Parameters.AddWithValue("@scholar", comboBox3.Text);
            com.Parameters.AddWithValue("@graduated", comboBox4.Text);
            com.Parameters.AddWithValue("@father", textBox9.Text);
            com.Parameters.AddWithValue("@mother", textBox10.Text);
            com.Parameters.AddWithValue("@cpe_fullname", textBox11.Text);
            com.Parameters.AddWithValue("@cpe_contactno", textBox12.Text);
            com.Parameters.AddWithValue("@date", label34.Text);
            com.Parameters.AddWithValue("@processedby", "System Administrator");
            com.Parameters.AddWithValue("@id", label38.Text);
        }

        private void buttonsave_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show("Please complete requied information.", "Missing Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                com = new MySqlCommand("insert into db_sisvone.tb_studentdetails(idnumber, lastname, firstname, middlename, couse, year_level, address, sex, birthdate, age, s_contactno, scholar, graduated, father, mother, cpe_fullname, cpe_contactno, date, processedby)values(@idnumber, @lastname, @firstname, @middlename, @couse, @year_level, @address, @sex, @birthdate, @age, @s_contactno, @scholar, @graduated, @father, @mother, @cpe_fullname, @cpe_contactno, @date, @processedby)", con);
                saveparams();
                dr = com.ExecuteReader();
                dr.Close();
                MessageBox.Show("New student details saved.", "Saved Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtclear();
            }
        }


        public void txtclear()
        {
            counts_reload();
            label38.Text = "-";
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            txtid.Text = DateTime.Now.ToString("yyyy-MMddhhmmss");
            Process.Start("simple_sis_mod.exe");
        }


        private void button7_Click(object sender, EventArgs e)
        {
            txtclear();
        }

        private void cboxyear_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void cboxyear_TextChanged_1(object sender, EventArgs e)
        {
            if (cboxyear.Text == "4th" || cboxyear.Text == "5th")
            {
                comboBox4.Text = "YES";
            }
            else
            {
                comboBox4.Text = "NO";
            }
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            int age = DateTime.Today.Year - dateTimePicker2.Value.Year;
            textBox6.Text = age.ToString();

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox11_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtid_TextChanged(object sender, EventArgs e)
        {

        }



        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || (char.IsDigit(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            textBox8.MaxLength = 11;
            if ((char.IsDigit(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;

            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox10_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox5_TextChanged_1(object sender, EventArgs e)
        {
        }
        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || (char.IsDigit(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label34.Text = DateTime.Now.ToString("yyyy-MM-dd  | ");
            label35.Text = DateTime.Now.ToString("hh:mm:ss tt");

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox12_KeyPress(object sender, KeyPressEventArgs e)
        {
            textBox12.MaxLength = 11;
            if ((char.IsLetter(e.KeyChar)) || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || (char.IsDigit(e.KeyChar)) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void listView1_Click(object sender, EventArgs e)
        {
            selectdetails();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (label38.Text == "-")
            {
                MessageBox.Show("Please click detials in the list first.", " Invalid Action", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show("Please complete requied information.", " Missing Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                com = new MySqlCommand("update db_sisvone.tb_studentdetails set id=@id, idnumber=@idnumber, lastname=@lastname, firstname=@firstname, middlename=@middlename, couse=@couse, year_level=@year_level, address=@address, sex=@sex, birthdate=@birthdate, age=@age, s_contactno=@s_contactno, scholar=@scholar, graduated=@graduated, father=@father, mother=@mother, cpe_fullname=@cpe_fullname, cpe_contactno=@cpe_contactno where id=@id;", con);
                saveparams();
                dr = com.ExecuteReader();
                dr.Close();
                MessageBox.Show("Student details updated.", " Updated Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtclear();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (label38.Text == "-")
            {
                MessageBox.Show("Please click detials in the list first.", " Invalid Action", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                DialogResult ask = MessageBox.Show("Are you sure to delete the student details?", "Ask To Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (ask == DialogResult.Yes)
                {
                    com = new MySqlCommand("delete from db_sisvone.tb_studentdetails where id=@id;",con);
                    saveparams();
                    dr = com.ExecuteReader();
                    dr.Close();
                    txtclear();
                    MessageBox.Show("A student details are now deleted.", "Deleted Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    txtclear();
                    MessageBox.Show("Deleting student details are now cancelled.", "Cancelled Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}

       
        
    

