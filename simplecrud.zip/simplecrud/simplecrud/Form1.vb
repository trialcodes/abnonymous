﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Dim con As New MySqlConnection("server=localhost;username=root;database=mysql;")
    Dim com As New MySqlCommand
    Dim dr As MySqlDataReader


    'OKAY WALA NA TAYUNG HINIHINTAY SIMULAN NA
    'FIRST OF ALL SYEMPRE GAGAWA MUN TAYU NG DATABASE DITO MISMO SA IDE NATIN PARA MAIBA AMAN 
    'pERO GAMIT NATIN IS MYSQL PA DIN'SO  LETS START

    Sub opencon()
        con.Close() ' need natin yan para di na tayu mag close ng connection every button then mag a auto open ulit
        con.Open()
        com.Connection = con
    End Sub

    Sub readerclosed() 'eto pang close aman ng reader natin sa bawat add edit and delete
        dr = com.ExecuteReader
        dr.Close()
    End Sub

    Sub create_database() 'tutal simple crud aman gustoi ng client kaya simplehan lang natin hehe
        com.CommandText = "create database if not exists db_simple_info;"
        'OH wait nakalimutan nating gumawa ng pang open ng connection and pang close ng reader
        readerclosed()
    End Sub

    Sub create_table() 'eto aman panggawa ng table hehe
        com.CommandText = "create table if not exists db_simple_info.tb_personal_info(id int(100) auto_increment primary key, firstname varchar(100), lastname varchar(100), age int(2), gender varchar(6), birthdate varchar(100));"
        readerclosed()
        '  MsgBox("Database and table created.", vbInformation, "Storage Ready")
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'lagay natin dito para automatically na mag create sya ng database and table'
        'oh sorry nakalimutan natin ilagay yung connection
        'okay na
        cbox1_gender() ' yan nakalimuatn natin
        lv1_design() 'lagay lang natin dito ' then check natin yown meron haha
        opencon()
        create_database()
        create_table()
        reload_details()
        Button1.Enabled = True
        Button2.Enabled = False
        Button4.Enabled = False
        'try natin irun
    End Sub

    'lagyan natin ng laman yung combobox automatically every load ng form
    Sub cbox1_gender()
        ComboBox1.Items.Clear()
        ComboBox1.Items.Add("MALE")
        ComboBox1.Items.Add("FEMALE")
        ComboBox1.Text = "MALE" 'para male agad yung magpapakita 
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged
        'eto aman ang code para iblock ang letters and symbols or any characters except number sa textbox3
        If TextBox3.Text = "" Then

        ElseIf Not IsNumeric(TextBox3.Text) Then
            TextBox3.Clear()
            MsgBox("Sorry! Only numbers allowed here.", vbExclamation, "Invalid Action")
            ' ngayun  try na natin yan
            'see? ok sya right? di nya inaaccept ang mga letters
        End If
    End Sub

    Sub insert_details()
        com.CommandText = "insert into db_simple_info.tb_personal_info(firstname,lastname,age,gender,birthdate)values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & ComboBox1.Text & "','" & DateTimePicker1.Text & "');"
        readerclosed() 'try natin ulit
        'wala pala tayu reader close dito kaya pala
        'di muna tayu gagamit ng parameter kasi simple lang naman daw 
        'yan kopyahin lang para jan natin i store mga iaadd nating details
        'see? okay na ngayung gawan muna natin ng select then update and delete
    End Sub

    'ngayun gawan naman natin ng update

    Sub update_details()
        com.CommandText = "update db_simple_info.tb_personal_info set id='" & ListView1.FocusedItem.Text & "', firstname='" & TextBox1.Text & "',lastname='" & TextBox2.Text & "',age='" & TextBox3.Text & "',gender='" & ComboBox1.Text & "',birthdate='" & DateTimePicker1.Text & "' where id='" & ListView1.FocusedItem.Text & "';"
        readerclosed() 'try natin ulit
        'wala pala tayu reader close dito kaya pala
        'di muna tayu gagamit ng parameter kasi simple lang naman daw 
        'yan kopyahin lang para jan natin i store mga iaadd nating details
        'see? okay na ngayung gawan muna natin ng select then update and delete
    End Sub

    'ganto lang sa delete

    Sub delete_details()
        com.CommandText = "delete from db_simple_info.tb_personal_info where id='" & ListView1.FocusedItem.Text & "';"
        readerclosed()
    End Sub

    Sub lv1_design() 'listview pala ginamit ko dito
        ListView1.View = View.Details
        ListView1.GridLines = True
        ListView1.FullRowSelect = True
        ListView1.Columns.Clear()
        ListView1.Columns.Add("#", 100)
        ListView1.Columns.Add("Firstname", 120)
        ListView1.Columns.Add("Lastname", 120)
        ListView1.Columns.Add("Age", 100)
        ListView1.Columns.Add("Gender", 100)
        ListView1.Columns.Add("Birthdate", 150)
    End Sub
    Sub reload_details()
        ListView1.Items.Clear()
        com.CommandText = "select * from db_simple_info.tb_personal_info order by id desc;" ' yan desc means descending kumbaga lahat nang na aadd mo napupunta sa unahan, try natin maya
        'okay try nalang natin other way for sure
        dr = com.ExecuteReader
        While dr.Read
            Dim details As New ListViewItem(dr.Item(0).ToString)
            Dim list As Integer
            For list = 1 To 5 Step 1
                details.SubItems.Add(dr.Item(list).ToString)
            Next
            ListView1.Items.AddRange(New ListViewItem() {details})
        End While
        dr.Close()
    End Sub

    Sub select_details()
        com.CommandText = "select * from db_simple_info.tb_personal_info where id='" & ListView1.FocusedItem.Text & "';" ' yan desc means descending kumbaga lahat nang na aadd mo napupunta sa unahan, try natin maya
        'okay try nalang natin other way for sure
        dr = com.ExecuteReader
        While dr.Read
            TextBox1.Text = dr.Item(1).ToString
            TextBox2.Text = dr.Item(2).ToString
            TextBox3.Text = dr.Item(3).ToString
            ComboBox1.Text = dr.Item(4).ToString
            DateTimePicker1.Value = dr.Item(5).ToString
        End While
        dr.Close()
    End Sub

    Sub txtclear() ' gawa muna pala tayu ng pang autoclear ng texboxes
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        ComboBox1.Text = "MALE"
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'ngayun lagyan na natin ng function tong add and auto display after add edit delete or auto reload ng mga details or information
        'pero dito lagyan muna natin ng condition na kung walang laman yung mga textboxed di pwede mag add same sa update maya
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Then
            MsgBox("Sorry! Please fill all required information. Thank you!", vbCritical, "Invalid Action")
        ElseIf Not ComboBox1.Text = "MALE" Or ComboBox1.Text = "FEMALE" Then ' oh wait nag kamamit tayu dito 
            MsgBox("You entered wrong gender. Please change.", vbExclamation, "Wrong Detail")
        Else
            insert_details()
            MsgBox("Personal information of Mr./Ms. " & TextBox2.Text & " now saved.", vbInformation, "Saved Successfully")
            reload_details() 'o sorry my nakalimutan tayu sa details
            txtclear()
            'woops gawa muna tayu reload bago natin irun

            'Yan try na natin
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        txtclear()
        reload_details()
    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        'dito natin ilalagay toh 
        select_details()
        'ngayun check na natin kung gagana dapat magpapakita mga laman ng sa textboxes
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Then
            MsgBox("Sorry! Please fill all required information. Thank you!", vbCritical, "Invalid Action")
        Else
            update_details() 'tapos eto lang palitan mo at etong nasa message box
            MsgBox("Personal information of Mr./Ms. " & TextBox2.Text & " now updated.", vbInformation, "Updated Successfully") ' try na natin
            reload_details() 'o sorry my nakalimutan tayu sa details
            txtclear()
            'woops gawa muna tayu reload bago natin irun
            'Yan try na natin
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub ComboBox1_TextChanged(sender As Object, e As EventArgs) Handles ComboBox1.TextChanged
        If ComboBox1.Text = "MALE" Or ComboBox1.Text = "FEMALE" Then
        Else
            MsgBox("You entered wrong gender. Please change.", vbExclamation, "Wrong Detail")
            ComboBox1.Text = "MALE"
            'jna try ulit natin
            'yown oks na yung sa gender
        End If ' oh wait nag kamamit tayu dito 
        'eto ilagay nalang natin sa combobox textchanged pala 

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'but wait gawa muna tayu ng blocker

    End Sub

    'ngayun sa delete aman tayu pero lagyan muna natin ng auto disable button kung naclick na yun list parang ganto
End Class
